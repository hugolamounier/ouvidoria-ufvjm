<div class="menu_wrapper z-depth-3 grey lighten-5">
        <div class="logo_mini"></div>
        <div class="division"></div>
        <div class="menu">
            <ul>
                <li onclick="location.href='?page=dashboard'" class="valign-wrapper" name="dashboard"><span><i class="material-icons left">assignment</i>Demandas<span></li>
                <li class="valign-wrapper" name="relatorios"><span><i class="material-icons left">content_paste</i>Relatórios<span></li>
                <li class="valign-wrapper" name="usuarios"><span><i class="material-icons left">people</i>Gerenciar Usuários<span></li>
                <li class="valign-wrapper" onclick="location.href='?logout=1'"><span><i class="material-icons left">exit_to_app</i>Sair<span></li>
            </ul>
        </div>
        <div class="menu_footer">
            <div class="division"></div>
            <div class="logo_ufvjm"></div>
        </div>
</div>