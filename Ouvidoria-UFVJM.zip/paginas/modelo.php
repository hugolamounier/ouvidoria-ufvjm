<?php

?>

<div class="title">
  <a onclick="location.href='?page=dashboard'" class="btn-floating btn-small waves-effect blue-grey lighten-3 tooltipped z-depth-0" data-position="bottom" data-tooltip="Voltar"><i class="material-icons">arrow_back</i></a>
  <span class="blue-grey-text text-darken-3">Adicionar Manifestação <span class=''blue-grey-text></span></span>
</div>
<div class="container">
  <div class="row">
    
  </div>
</div>